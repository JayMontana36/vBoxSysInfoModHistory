Credits:
 - JayMontana36 (Original creator and maintainer of vBox System Information Modifier (aka vBox System Info Modifier, VirtualBox VM System Information Modifier, etc))

NOTES:
 - If you did not obtain this program from https://sites.google.com/site/jaymontana36jasen please delete it and obtain it through that site (just to be on the safe side)

Running: You must have VirtualBox installed in it's default location, otherwise this program will not work; if you have it installed in another location, you may create a symlink or shortcut to your install directory from the default install directory as a workaround. This program will verify the existance of the VirtualBox directory before allowing you to continue, but will not verify whether or not the VM name you choose exists (make sure you type it AS IS, NO MISTAKES) and also will not verify whether a specific system of your choice exists (so you can set fake vandors and systems or just straight up type jibberish and it'd still work).

What inspired the creation of this little program/script: This script was created to help scammer exposers using VirtualBox VMs to change the system information which shows up in various places of the system (mainly cough cough msinfo32 cough cough) to help waste more of the scammer's time as well as keep things going much longer, making the scammer believe that it is a real system.

What this program is currently capable of: This program in it's current form at the time of writing replaces vBox system information with user-selected system information, as well as randomly generating serial numbers, system skus, bios versions/dates, etc. Each time you use the program on a VM, new system info is generated and applied to the specified VM, even if you input the same system info as before. Supports BIOS and EFI modes.
