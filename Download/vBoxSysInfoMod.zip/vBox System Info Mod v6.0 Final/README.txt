Credits:
 - JayMontana36 (Original creator and maintainer of vBoxSysInfoMod (aka vBox System Information Modifier, vBox System Info Modifier, VirtualBox VM System Information Modifier, etc))

NOTES:
 - If you did not obtain this program from "https://sites.google.com/site/jaymontana36jasen" or from "https://github.com/JayMontana36/vBoxSysInfoMod" please delete it and obtain it through one of those two sites (just to be on the safe side)

Running: Self-explanitory.

What inspired the creation of this little script/program: This script was created mainly to allow scambaiters using VirtualBox VMs to modify the system information that shows up in various places of the system (in msinfo32 and Task Manager for example) to give the illusion of a real non-virtualized system in order to help waste more of a scammer's time by keeping things going for a much longer time, making the scammer believe that it is a real actual legitimate system.

What this program is currently capable of: This program in it's current form at the time of writing replaces vBox system information with user-selected system information, randomly generating serial numbers, system skus, bios versions/dates, automatically hides/masks Task Manager indicators, etc. Each time you use the program on a VM, new system info is generated and applied to the specified VM, even if you decide to input the same exact system information as before. Supports both the BIOS and EFI modes.
